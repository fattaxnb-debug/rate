/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  const field = collection.fields.getByName("technician_id");
  field.required = true;
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  const field = collection.fields.getByName("technician_id");
  field.required = true;
  return app.save(collection);
})