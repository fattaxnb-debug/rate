/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("clients");
  collection.listRule = "@request.auth.id != \"\"";
  collection.viewRule = "@request.auth.id != \"\"";
  collection.createRule = "@request.auth.role = \"Gerente\" || @request.auth.role = \"T\u00e9cnico\"";
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("clients");
  collection.createRule = "@request.auth.role = \"Gerente\"";
  collection.listRule = "@request.auth.id != \"\"";
  collection.viewRule = "@request.auth.id != \"\"";
  return app.save(collection);
})