/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("clients");


}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})