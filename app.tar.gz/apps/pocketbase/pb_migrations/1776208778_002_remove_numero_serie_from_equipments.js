/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  collection.fields.removeByName("numero_serie");
  return app.save(collection);
}, (app) => {

  const collection = app.findCollectionByNameOrId("equipments");
  collection.fields.add(new TextField({
    name: "numero_serie",
    required: false,
    min: 0,
    max: 0
  }));
  return app.save(collection);
})