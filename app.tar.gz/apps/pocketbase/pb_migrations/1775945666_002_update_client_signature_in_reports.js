/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("reports");
  const field = collection.fields.getByName("client_signature");
  field.max = 50000;
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("reports");
  const field = collection.fields.getByName("client_signature");
  field.max = 0;
  return app.save(collection);
})