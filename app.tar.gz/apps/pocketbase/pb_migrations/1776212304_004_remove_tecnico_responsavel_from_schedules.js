/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  collection.fields.removeByName("tecnico_responsavel");
  return app.save(collection);
}, (app) => {

  const _pb_users_auth_Collection = app.findCollectionByNameOrId("_pb_users_auth_");
  const collection = app.findCollectionByNameOrId("schedules");
  collection.fields.add(new RelationField({
    name: "tecnico_responsavel",
    required: true,
    collectionId: _pb_users_auth_Collection.id,
    maxSelect: 0,
    cascadeDelete: false
  }));
  return app.save(collection);
})