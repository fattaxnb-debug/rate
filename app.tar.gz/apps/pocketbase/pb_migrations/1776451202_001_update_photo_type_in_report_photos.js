/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("report_photos");
  const field = collection.fields.getByName("photo_type");
  field.values = ["photo", "client_signature"];
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("report_photos");
  const field = collection.fields.getByName("photo_type");
  if (!field) { console.log("Field not found, skipping revert"); return; }
  field.values = ["External", "Internal", "Damage", "Installation", "Other"];
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection or field not found, skipping revert");
      return;
    }
    throw e;
  }
})