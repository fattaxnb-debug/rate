/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  collection.createRule = "@request.auth.role = \"Gerente\" || @request.auth.role = \"T\u00e9cnico\"";
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  collection.createRule = "@request.auth.role = \"Gerente\" || @request.auth.role = \"T\u00e9cnico\"";
  return app.save(collection);
})