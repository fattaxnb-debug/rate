/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("reports");

  const existing = collection.fields.getByName("external_battery_nobreak_connection");
  if (existing) {
    if (existing.type === "select") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("external_battery_nobreak_connection"); // exists with wrong type, remove first
  }

  collection.fields.add(new SelectField({
    name: "external_battery_nobreak_connection",
    required: false,
    values: ["DISJUNTOR", "BORNE", "DIRETO"]
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("reports");
    collection.fields.removeByName("external_battery_nobreak_connection");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})