/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("clients");
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_clients_cnpj_cpf"));
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("clients");
  collection.indexes.push("CREATE UNIQUE INDEX idx_clients_cnpj_cpf ON clients (cnpj_cpf)");
  return app.save(collection);
})