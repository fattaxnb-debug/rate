/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  collection.listRule = "@request.auth.id != \"\"";
  collection.viewRule = "@request.auth.id != \"\"";
  collection.createRule = "@request.auth.role = \"Gerente\" || @request.auth.role = \"T\u00e9cnico\"";
  collection.updateRule = "@request.auth.role = \"Gerente\" || (@request.auth.role = \"T\u00e9cnico\" && @request.auth.id = technician_id)";
  collection.deleteRule = "@request.auth.role = \"Gerente\"";
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  collection.listRule = "@request.auth.id != \"\"";
  collection.viewRule = "@request.auth.id != \"\"";
  collection.createRule = "@request.auth.role = \"Gerente\" || @request.auth.role = \"T\u00e9cnico\"";
  collection.updateRule = "@request.auth.role = \"Gerente\" || (@request.auth.role = \"T\u00e9cnico\" && @request.auth.id = tecnico_responsavel)";
  collection.deleteRule = "@request.auth.role = \"Gerente\"";
  return app.save(collection);
})