/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("report_photos");

  const existing = collection.fields.getByName("photo_url");
  if (existing) {
    if (existing.type === "file") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("photo_url"); // exists with wrong type, remove first
  }

  collection.fields.add(new FileField({
    name: "photo_url",
    required: true,
    maxSelect: 1,
    maxSize: 20971520
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("report_photos");
  collection.fields.removeByName("photo_url");
  return app.save(collection);
})