/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("report_photos");
  collection.fields.removeByName("photo_url");
  return app.save(collection);
}, (app) => {

  const collection = app.findCollectionByNameOrId("report_photos");
  collection.fields.add(new TextField({
    name: "photo_url",
    required: true,
    min: 0,
    max: 50000
  }));
  return app.save(collection);
})