/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("report_photos");
  const field = collection.fields.getByName("photo_url");
  field.max = 50000;
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("report_photos");
  const field = collection.fields.getByName("photo_url");
  field.max = 0;
  return app.save(collection);
})