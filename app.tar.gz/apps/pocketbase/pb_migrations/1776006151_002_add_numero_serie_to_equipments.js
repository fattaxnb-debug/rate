/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("equipments");

  const existing = collection.fields.getByName("numero_serie");
  if (existing) {
    if (existing.type === "text") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("numero_serie"); // exists with wrong type, remove first
  }

  collection.fields.add(new TextField({
    name: "numero_serie",
    required: true
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  collection.fields.removeByName("numero_serie");
  return app.save(collection);
})