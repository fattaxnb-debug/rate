/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("equipments");

  const existing = collection.fields.getByName("battery_connection");
  if (existing) {
    if (existing.type === "select") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("battery_connection"); // exists with wrong type, remove first
  }

  collection.fields.add(new SelectField({
    name: "battery_connection",
    required: false,
    values: ["CABOS", "BARRA", "CABOS E BARRAS"]
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("equipments");
    collection.fields.removeByName("battery_connection");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})