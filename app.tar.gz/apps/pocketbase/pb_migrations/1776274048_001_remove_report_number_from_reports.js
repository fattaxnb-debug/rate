/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("reports");
  collection.fields.removeByName("report_number");
  return app.save(collection);
}, (app) => {
  try {

  const collection = app.findCollectionByNameOrId("reports");
  collection.fields.add(new NumberField({
    name: "report_number",
    required: false
  }));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})