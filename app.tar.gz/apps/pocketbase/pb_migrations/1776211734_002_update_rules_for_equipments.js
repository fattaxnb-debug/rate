/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  collection.listRule = "@request.auth.id != \"\"";
  collection.viewRule = "@request.auth.id != \"\"";
  collection.createRule = "@request.auth.role = \"Gerente\" || @request.auth.role = \"T\u00e9cnico\"";
  collection.updateRule = "@request.auth.role = \"Gerente\"";
  collection.deleteRule = "@request.auth.role = \"Gerente\"";
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  collection.listRule = "@request.auth.id != \"\"";
  collection.viewRule = "@request.auth.id != \"\"";
  collection.createRule = "@request.auth.role = \"Gerente\" || @request.auth.role = \"T\u00e9cnico\"";
  collection.updateRule = "@request.auth.role = \"Gerente\"";
  collection.deleteRule = "@request.auth.role = \"Gerente\"";
  return app.save(collection);
})