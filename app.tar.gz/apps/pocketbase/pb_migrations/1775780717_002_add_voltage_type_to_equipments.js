/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("equipments");

  const existing = collection.fields.getByName("voltage_type");
  if (existing) {
    if (existing.type === "select") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("voltage_type"); // exists with wrong type, remove first
  }

  collection.fields.add(new SelectField({
    name: "voltage_type",
    required: false,
    values: ["TRIF\u00c1SICA", "TRIMONO", "MONOF\u00c1SICA"]
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  collection.fields.removeByName("voltage_type");
  return app.save(collection);
})