/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("equipments");

  const existing = collection.fields.getByName("cooled_environment");
  if (existing) {
    if (existing.type === "select") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("cooled_environment"); // exists with wrong type, remove first
  }

  collection.fields.add(new SelectField({
    name: "cooled_environment",
    required: false,
    values: ["SIM", "N\u00c3O"]
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("equipments");
    collection.fields.removeByName("cooled_environment");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})