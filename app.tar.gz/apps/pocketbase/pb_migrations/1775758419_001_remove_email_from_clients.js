/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("clients");
  collection.fields.removeByName("email");
  return app.save(collection);
}, (app) => {

  const collection = app.findCollectionByNameOrId("clients");
  collection.fields.add(new EmailField({
    name: "email",
    required: false
  }));
  return app.save(collection);
})