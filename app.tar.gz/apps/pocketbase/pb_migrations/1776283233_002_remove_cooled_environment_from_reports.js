/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("reports");
  collection.fields.removeByName("cooled_environment");
  return app.save(collection);
}, (app) => {
  try {

  const collection = app.findCollectionByNameOrId("reports");
  collection.fields.add(new BoolField({
    name: "cooled_environment",
    required: false
  }));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})