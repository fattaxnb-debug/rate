/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("equipments");

  const existing = collection.fields.getByName("symmetric");
  if (existing) {
    if (existing.type === "text") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("symmetric"); // exists with wrong type, remove first
  }

  collection.fields.add(new TextField({
    name: "symmetric",
    required: false
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  collection.fields.removeByName("symmetric");
  return app.save(collection);
})