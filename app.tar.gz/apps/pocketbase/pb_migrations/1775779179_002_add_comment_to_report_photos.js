/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("report_photos");

  const existing = collection.fields.getByName("comment");
  if (existing) {
    if (existing.type === "text") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("comment"); // exists with wrong type, remove first
  }

  collection.fields.add(new TextField({
    name: "comment",
    required: false
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("report_photos");
  collection.fields.removeByName("comment");
  return app.save(collection);
})