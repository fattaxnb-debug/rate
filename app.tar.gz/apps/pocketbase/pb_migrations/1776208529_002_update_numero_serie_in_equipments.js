/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  const field = collection.fields.getByName("numero_serie");
  field.required = false;
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  const field = collection.fields.getByName("numero_serie");
  field.required = true;
  return app.save(collection);
})