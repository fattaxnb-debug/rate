/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  collection.updateRule = "@request.auth.role = \"Gerente\" || (@request.auth.role = \"T\u00e9cnico\" && @request.auth.id = tecnico_responsavel)";
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  collection.updateRule = "@request.auth.role = \"Gerente\" || (@request.auth.role = \"T\u00e9cnico\" && @request.auth.id = technician_id)";
  return app.save(collection);
})