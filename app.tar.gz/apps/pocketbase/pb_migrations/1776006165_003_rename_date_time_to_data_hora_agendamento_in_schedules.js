/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  const field = collection.fields.getByName("date_time");
  field.name = "data_hora_agendamento";
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  const field = collection.fields.getByName("data_hora_agendamento");
  field.name = "date_time";
  return app.save(collection);
})