/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const usersCollection = app.findCollectionByNameOrId("users");
  const collection = app.findCollectionByNameOrId("schedules");

  const existing = collection.fields.getByName("tecnico_responsavel");
  if (existing) {
    if (existing.type === "relation") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("tecnico_responsavel"); // exists with wrong type, remove first
  }

  collection.fields.add(new RelationField({
    name: "tecnico_responsavel",
    required: true,
    collectionId: usersCollection.id
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  collection.fields.removeByName("tecnico_responsavel");
  return app.save(collection);
})