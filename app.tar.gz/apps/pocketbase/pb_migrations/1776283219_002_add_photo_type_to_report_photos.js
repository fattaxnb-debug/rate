/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("report_photos");

  const existing = collection.fields.getByName("photo_type");
  if (existing) {
    if (existing.type === "select") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("photo_type"); // exists with wrong type, remove first
  }

  collection.fields.add(new SelectField({
    name: "photo_type",
    required: false,
    values: ["External", "Internal", "Damage", "Installation", "Other"]
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("report_photos");
    collection.fields.removeByName("photo_type");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})