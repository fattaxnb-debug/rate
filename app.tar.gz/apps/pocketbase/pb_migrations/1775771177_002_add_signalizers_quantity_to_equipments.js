/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("equipments");

  const existing = collection.fields.getByName("signalizers_quantity");
  if (existing) {
    if (existing.type === "number") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("signalizers_quantity"); // exists with wrong type, remove first
  }

  collection.fields.add(new NumberField({
    name: "signalizers_quantity",
    required: false
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  collection.fields.removeByName("signalizers_quantity");
  return app.save(collection);
})