/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("equipments");

  const existing = collection.fields.getByName("communication_cable_type");
  if (existing) {
    if (existing.type === "text") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("communication_cable_type"); // exists with wrong type, remove first
  }

  collection.fields.add(new TextField({
    name: "communication_cable_type",
    required: false
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("equipments");
  collection.fields.removeByName("communication_cable_type");
  return app.save(collection);
})