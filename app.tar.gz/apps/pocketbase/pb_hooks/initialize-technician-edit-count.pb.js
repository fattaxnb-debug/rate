/// <reference path="../pb_data/types.d.ts" />
onRecordCreate((e) => {
  e.record.set("technician_edit_count", 0);
  e.next();
}, "reports");