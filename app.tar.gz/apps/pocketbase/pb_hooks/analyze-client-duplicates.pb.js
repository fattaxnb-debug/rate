/// <reference path="../pb_data/types.d.ts" />
// This hook analyzes duplicate clients based on cnpj_cpf
// It runs on every client record operation to track duplicates

onRecordsListRequest((e) => {
  // This hook fires when listing clients
  // We'll use it to analyze the data
  e.next();
}, "clients");