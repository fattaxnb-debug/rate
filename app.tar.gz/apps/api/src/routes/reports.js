import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// DELETE /reports/:id - Exclusão em cascata
router.delete('/:id', async (req, res) => {
  const { id } = req.params;

  logger.info(`Iniciando exclusão do relatório: ${id}`);

  // 1. Buscar o relatório
  const report = await pb.collection('reports').getOne(id);
  
  if (!report) {
    logger.warn(`Relatório não encontrado: ${id}`);
    return res.status(404).json({ error: 'Relatório não encontrado' });
  }

  logger.info(`Relatório encontrado: ${id}`);

  // 2. Buscar todas as fotos relacionadas
  const photos = await pb.collection('report_photos').getList(1, 500, {
    filter: `report_id="${id}"`,
  });

  logger.info(`Encontradas ${photos.items.length} fotos para o relatório ${id}`);

  // 3. Deletar cada foto
  for (const photo of photos.items) {
    await pb.collection('report_photos').delete(photo.id);
    logger.info(`Foto deletada: ${photo.id}`);
  }

  logger.info(`Todas as ${photos.items.length} fotos foram deletadas`);

  // 4. Deletar o relatório
  await pb.collection('reports').delete(id);
  logger.info(`Relatório deletado com sucesso: ${id}`);

  // 5. Retornar sucesso
  res.json({
    success: true,
    message: 'Relatório deletado com sucesso',
    deletedPhotosCount: photos.items.length,
  });
});

export default router;