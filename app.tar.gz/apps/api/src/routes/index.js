import { Router } from 'express';
import healthCheck from './health-check.js';
import reportsRouter from './reports.js';

const router = Router();

export default () => {
    router.get('/health', healthCheck);
    router.use('/reports', reportsRouter);

    return router;
};