
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Calendar } from '@/components/ui/calendar';
import { toast } from 'sonner';
import { Check, ChevronsUpDown, Upload, X, ZoomIn, ArrowRight, ArrowLeft, Save, Settings2, Zap, Battery, Activity, FileText, Image as ImageIcon, PenTool, MonitorSmartphone, AlertCircle, Calendar as CalendarIcon, Clock } from 'lucide-react';
import pb from '@/lib/pocketbaseClient.js';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { useSearch } from '@/hooks/useSearch.js';
import { compressImage } from '@/utils/imageCompression.js';
import SignatureCanvas from 'react-signature-canvas';
import { cn } from '@/lib/utils.js';
import EquipmentSelectionModal from '@/components/EquipmentSelectionModal.jsx';
import { format } from 'date-fns';

const INSTALLATION_LOCATION_OPTIONS = ['Adequado', 'Inadequado'];
const POWER_SUPPLY_TYPES = ['Circuito', 'Tomada', 'Tomada Industrial'];
const BATTERY_TYPES = ['Interno', 'Externo'];
const COOLED_ENV_OPTIONS = ['SIM', 'NÃO'];
const EXTERNAL_BATTERY_CONNECTION_OPTIONS = ['DISJUNTOR', 'BORNE', 'DIRETO'];
const YES_NO_OPTIONS = ['SIM', 'NÃO'];

export default function ReportForm() {
  const { clientId, scheduleId } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('equipment');
  const [validationErrors, setValidationErrors] = useState([]);
  
  const [clients, setClients] = useState([]);
  const [technicians, setTechnicians] = useState([]);
  const [clientEquipments, setClientEquipments] = useState([]);
  const [clientOpen, setClientOpen] = useState(false);
  const [equipmentModalOpen, setEquipmentModalOpen] = useState(false);
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [createdDate, setCreatedDate] = useState(new Date());
  
  const { searchTerm: clientSearchTerm, setSearchTerm: setClientSearchTerm, filteredItems: filteredClients } = useSearch(clients, ['name', 'cnpj_cpf']);
  
  const [formData, setFormData] = useState({
    client_id: clientId || '',
    equipment_id: '',
    technician_id: currentUser?.role === 'Técnico' ? currentUser.id : '',
    schedule_id: scheduleId || '',
    service_order_number: '',
    service_type: '',
    responsible_person: '',
    installation_location: '',
    installation_location_explanation: '',
    power_supply_type: '',
    breaker: '',
    cable_entry_phase: '',
    cable_entry_neutral: '',
    cable_entry_ground: '',
    cable_exit_phase: '',
    cable_exit_neutral: '',
    external_inspection: '',
    internal_inspection: '',
    attendance_description: '',
    diagnosis: '',
    conclusion: '',
    cooled_environment: '',
    electrical_measurements: { entrada: { tensions: {}, currents: {} }, saida: { tensions: {}, currents: {} } },
    battery_bank: { 
      type: '', 
      quantity: '', 
      battery_volts: '',
      battery_current: '',
      voltage: '', 
      voltage_positive_neutral: '',
      voltage_neutral_negative: '',
      charger_voltage: '', 
      brand: '', 
      model: '',
      trocou_baterias: '',
      last_change: '',
      motivo_nao_troca: ''
    },
    external_battery_positive_cable: '',
    external_battery_negative_cable: '',
    external_battery_neutral_cable: '',
    external_battery_connection: '',
    external_battery_nobreak_connection: '',
    technician_signature: '',
    client_signature: '',
    technician_edit_count: 0
  });

  const [selectedEquipmentData, setSelectedEquipmentData] = useState(null);
  const [photos, setPhotos] = useState([]);
  const [zoomPhoto, setZoomPhoto] = useState(null);
  const clientSigPad = useRef(null);
  const techSigPad = useRef(null);

  const isTech = currentUser?.role === 'Técnico';
  const isReadOnly = false; 

  useEffect(() => {
    initForm();
  }, [clientId, scheduleId]);

  const initForm = async () => {
    try {
      const [clientsRes, techRes] = await Promise.all([
        pb.collection('clients').getFullList({ sort: 'name', $autoCancel: false }),
        pb.collection('users').getFullList({ filter: "role='Técnico'", sort: 'name', $autoCancel: false })
      ]);
      
      setClients(clientsRes);
      setTechnicians(techRes);
      
      if (clientId) {
        await fetchClientEquipments(clientId);
      }
      
      if (scheduleId) {
        const schedule = await pb.collection('schedules').getOne(scheduleId, { $autoCancel: false });
        if (!formData.client_id) {
          setFormData(prev => ({ ...prev, client_id: schedule.client_id }));
          await fetchClientEquipments(schedule.client_id);
        }
      }
      
      await generateNextOsNumber();
      
      if (formData.technician_id || currentUser?.id) {
        await handleTechnicianSignature(formData.technician_id || currentUser.id);
      }
      
      setLoading(false);
    } catch (error) {
      toast.error('Erro ao carregar dados do formulário');
      setLoading(false);
    }
  };

  const generateNextOsNumber = async () => {
    try {
      const highestReport = await pb.collection('reports').getList(1, 1, { sort: '-created', $autoCancel: false });
      const now = new Date();
      const yearMonth = `${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}`;
      let nextSeq = 1;
      if (highestReport.items.length > 0 && highestReport.items[0].service_order_number) {
        const match = highestReport.items[0].service_order_number.match(/RAT-\d{6}-(\d+)/);
        if (match) nextSeq = parseInt(match[1], 10) + 1;
      }
      setFormData(prev => ({ ...prev, service_order_number: `RAT-${yearMonth}-${nextSeq.toString().padStart(4, '0')}` }));
    } catch (e) {}
  };

  const fetchClientEquipments = async (cId) => {
    try {
      const eqs = await pb.collection('equipments').getFullList({ filter: `client_id = "${cId}"`, sort: 'type', $autoCancel: false });
      setClientEquipments(eqs);
    } catch (e) {
      toast.error('Erro ao carregar equipamentos do cliente');
    }
  };

  const handleTechnicianSignature = async (techId) => {
    if (!techId) return;
    
    try {
      const tech = technicians.find(t => t.id === techId) || await pb.collection('users').getOne(techId, { $autoCancel: false });
      const techName = tech?.name?.toUpperCase() || '';
      
      const settings = await pb.collection('company_settings').getFirstListItem(`userId="${currentUser.id}"`, { $autoCancel: false });
      
      let sigUrl = '';
      if (techName.includes('TIAGO') && techName.includes('VIANA') && settings.signature_tiago_viana) {
        sigUrl = pb.files.getUrl(settings, settings.signature_tiago_viana);
      } else if (techName.includes('TITO') && techName.includes('LIVIO') && settings.signature_tito_livio) {
        sigUrl = pb.files.getUrl(settings, settings.signature_tito_livio);
      } else if (settings.technician_signature_1) {
        sigUrl = pb.files.getUrl(settings, settings.technician_signature_1);
      }
      
      if (sigUrl) {
        setFormData(prev => ({ ...prev, technician_signature: sigUrl }));
      }
    } catch (e) {
      console.error('Error loading technician signature:', e);
    }
  };

  const handleTechChange = async (techId) => {
    setFormData(prev => ({ ...prev, technician_id: techId }));
    await handleTechnicianSignature(techId);
  };

  const handleClientChange = async (cId) => {
    setFormData(prev => ({ ...prev, client_id: cId, equipment_id: '' }));
    setSelectedEquipmentData(null);
    await fetchClientEquipments(cId);
    setValidationErrors([]);
  };

  const selectEquipment = (eq) => {
    setFormData(prev => ({ ...prev, equipment_id: eq.id }));
    setSelectedEquipmentData(eq);
    setEquipmentModalOpen(false);
    setValidationErrors([]);
  };

  const validateForm = () => {
    const errors = [];
    if (!formData.client_id) errors.push('Selecione um cliente.');
    if (!formData.technician_id) errors.push('Selecione um Técnico Responsável.');
    if (!formData.equipment_id) errors.push('Selecione um equipamento.');
    
    if (formData.equipment_id) {
      if (!formData.service_type) errors.push('Informe o Tipo de Serviço.');
    }
    
    setValidationErrors(errors);
    if (errors.length > 0) {
      toast.error('Preencha os campos obrigatórios antes de salvar.');
      return false;
    }
    return true;
  };

  const hasBattery = selectedEquipmentData?.type === 'Nobreak';
  const hasExternalBattery = selectedEquipmentData?.type === 'Nobreak' && selectedEquipmentData?.battery_type === 'Externo';
  const isSymmetric = selectedEquipmentData?.symmetric === 'Sim';
  const trocouBaterias = formData.battery_bank.trocou_baterias;
  const tabsOrder = ['equipment', 'installation', 'electrical', ...(hasBattery ? ['battery'] : []), 'attendance', 'photos', 'signatures'];

  const handleNextTab = () => {
    const idx = tabsOrder.indexOf(activeTab);
    if (idx < tabsOrder.length - 1) {
      setActiveTab(tabsOrder[idx + 1]);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrevTab = () => {
    const idx = tabsOrder.indexOf(activeTab);
    if (idx > 0) {
      setActiveTab(tabsOrder[idx - 1]);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleConfirmSignature = () => {
    if (clientSigPad.current && !clientSigPad.current.isEmpty()) {
      const base64 = clientSigPad.current.toDataURL('image/png');
      updateField('client_signature', base64);
      toast.success('Assinatura confirmada com sucesso');
    } else {
      toast.error('Por favor, assine antes de confirmar');
    }
  };

  const clearClientSignature = () => {
    if (clientSigPad.current) {
      clientSigPad.current.clear();
    }
  };

  const redrawClientSignature = () => {
    updateField('client_signature', '');
    setTimeout(() => {
      if (clientSigPad.current) {
        clientSigPad.current.clear();
      }
    }, 50);
  };

  const handleConfirmTechSignature = () => {
    if (techSigPad.current && !techSigPad.current.isEmpty()) {
      const base64 = techSigPad.current.toDataURL('image/png');
      updateField('technician_signature', base64);
      toast.success('Assinatura do técnico confirmada com sucesso');
    } else {
      toast.error('Por favor, assine antes de confirmar');
    }
  };

  const clearTechSignature = () => {
    if (techSigPad.current) {
      techSigPad.current.clear();
    }
  };

  const redrawTechSignature = () => {
    updateField('technician_signature', '');
    setTimeout(() => {
      if (techSigPad.current) {
        techSigPad.current.clear();
      }
    }, 50);
  };

  const processPhotos = async (recordId) => {
    for (const photo of photos) {
      if (photo.file) {
        const formDataObj = new FormData();
        formDataObj.append('report_id', recordId);
        formDataObj.append('photo_url', photo.file);
        formDataObj.append('comment', photo.comment || '');
        formDataObj.append('photo_type', photo.photo_type || '');
        if (photo.sequence) formDataObj.append('sequence', photo.sequence);
        await pb.collection('report_photos').create(formDataObj, { $autoCancel: false });
      }
    }
  };

  const handleCreateDraft = async () => {
    if (!validateForm()) return;
    setSaving(true);
    
    const payload = { 
      ...formData,
      attendance_date_time: new Date().toISOString(),
      created_date: createdDate.toISOString().split('T')[0],
      external_battery_positive_cable: formData.external_battery_positive_cable || null,
      external_battery_negative_cable: formData.external_battery_negative_cable || null,
      external_battery_neutral_cable: formData.external_battery_neutral_cable || null,
      external_battery_connection: formData.external_battery_connection || null,
      external_battery_nobreak_connection: formData.external_battery_nobreak_connection || null,
      technician_edit_count: 0
    };
    
    try {
      const record = await pb.collection('reports').create(payload, { $autoCancel: false });
      await processPhotos(record.id);
      
      toast.success('Relatório salvo com sucesso!');
      navigate('/reports');
    } catch (error) {
      toast.error('Erro ao criar relatório: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  const handleQuickCreate = async () => {
    if (!validateForm()) return;
    setSaving(true);
    
    const payload = { 
      client_id: formData.client_id,
      equipment_id: formData.equipment_id,
      technician_id: formData.technician_id,
      created_date: createdDate.toISOString().split('T')[0],
      service_order_number: formData.service_order_number,
      service_type: formData.service_type,
      technician_edit_count: 0
    };
    
    try {
      await pb.collection('reports').create(payload, { $autoCancel: false });
      toast.success('Relatório criado com sucesso!');
      navigate('/reports');
    } catch (error) {
      toast.error('Erro ao criar relatório: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (validationErrors.length > 0) setValidationErrors([]);
  };

  const updateElectrical = (section, type, field, value) => {
    setFormData(prev => {
      const updated = { ...prev };
      if (!updated.electrical_measurements[section]) updated.electrical_measurements[section] = { tensions: {}, currents: {} };
      
      if (type === 'frequency') {
        updated.electrical_measurements[section].frequency = value;
      } else {
        if (!updated.electrical_measurements[section][type]) updated.electrical_measurements[section][type] = {};
        updated.electrical_measurements[section][type][field] = value;
      }
      return updated;
    });
  };

  const updateBattery = (field, value) => {
    setFormData(prev => ({ ...prev, battery_bank: { ...prev.battery_bank, [field]: value } }));
  };

  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files);
    for (const file of files) {
      try {
        const { file: compressedFile, dataUrl } = await compressImage(file, 800);
        setPhotos(prev => [...prev, { id: `temp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`, url: dataUrl, file: compressedFile, comment: '', sequence: prev.length + 1 }]);
      } catch (error) {
        toast.error('Erro ao processar imagem');
      }
    }
  };

  const updatePhoto = (photoId, field, value) => {
    setPhotos(prev => prev.map(p => p.id === photoId ? { ...p, [field]: value } : p));
  };

  const removePhoto = (photoId) => {
    setPhotos(prev => prev.filter(p => p.id !== photoId));
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('pt-BR');
    } catch {
      return '-';
    }
  };

  const formatDateForDisplay = (isoDate) => {
    if (!isoDate) return '';
    try {
      const date = new Date(isoDate);
      return format(date, 'dd/MM/yyyy');
    } catch {
      return '';
    }
  };

  const shouldDisplayField = (value) => {
    if (value === null || value === undefined || value === '') return false;
    if (typeof value === 'number' && value === 0) return false;
    if (typeof value === 'string' && value.trim() === '') return false;
    return true;
  };

  const renderEquipmentField = (label, value) => {
    if (!shouldDisplayField(value)) return null;
    return (
      <div>
        <span className="text-muted-foreground block text-[10px] font-bold uppercase tracking-wide">{label}</span>
        <span className="font-medium text-sm">{value}</span>
      </div>
    );
  };

  const handleCancel = () => {
    navigate('/reports');
  };

  if (loading) {
    return <div className="flex justify-center items-center py-24"><div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full"></div></div>;
  }

  const vType = selectedEquipmentData?.voltage_type;
  const getElecValue = (section, type, field) => formData.electrical_measurements?.[section]?.[type]?.[field] || '';
  const selectedTech = technicians.find(t => t.id === formData.technician_id);

  return (
    <div className="bg-background">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">
            Novo Relatório {formData.service_order_number && `- OS: ${formData.service_order_number}`}
          </h2>
          {selectedEquipmentData && (
            <p className="text-muted-foreground font-medium mt-1 text-sm flex items-center gap-2">
              <MonitorSmartphone className="h-4 w-4" />
              {selectedEquipmentData.type} ({selectedEquipmentData.brand} - {selectedEquipmentData.serial_number})
            </p>
          )}
        </div>
        <div className="space-y-2">
          <Label>Data do Relatório</Label>
          <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-start text-left font-normal" disabled={isReadOnly}>
                <CalendarIcon className="mr-2 h-4 w-4" />
                {format(createdDate, 'dd/MM/yyyy')}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                mode="single"
                selected={createdDate}
                onSelect={(date) => {
                  if (date) setCreatedDate(date);
                  setDatePickerOpen(false);
                }}
                disabled={(date) => date > new Date()}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>
      </div>

      {validationErrors.length > 0 && !isReadOnly && (
        <div className="mb-6 p-4 bg-destructive/10 border border-destructive/20 rounded-xl text-destructive flex items-start gap-3">
          <AlertCircle className="h-5 w-5 mt-0.5 shrink-0" />
          <div>
            <h4 className="font-semibold mb-1">Verifique os campos obrigatórios:</h4>
            <ul className="list-disc list-inside text-sm space-y-1 ml-4">
              {validationErrors.map((err, i) => <li key={i}>{err}</li>)}
            </ul>
          </div>
        </div>
      )}

      <fieldset disabled={isReadOnly} className="bg-card rounded-xl border shadow-sm overflow-hidden flex flex-col min-h-[600px] group">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full flex-1 flex flex-col">
          <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0 h-auto overflow-x-auto flex-nowrap shrink-0">
            <TabsTrigger value="equipment" className="data-[state=active]:border-primary data-[state=active]:text-primary border-b-2 border-transparent rounded-none px-6 py-3 font-semibold"><Settings2 className="w-4 h-4 mr-2"/> Equipamento</TabsTrigger>
            <TabsTrigger value="installation" disabled={!formData.equipment_id} className="data-[state=active]:border-primary data-[state=active]:text-primary border-b-2 border-transparent rounded-none px-6 py-3 font-semibold"><Activity className="w-4 h-4 mr-2"/> Instalação</TabsTrigger>
            <TabsTrigger value="electrical" disabled={!formData.equipment_id} className="data-[state=active]:border-primary data-[state=active]:text-primary border-b-2 border-transparent rounded-none px-6 py-3 font-semibold"><Zap className="w-4 h-4 mr-2"/> Elétrica</TabsTrigger>
            {hasBattery && <TabsTrigger value="battery" disabled={!formData.equipment_id} className="data-[state=active]:border-primary data-[state=active]:text-primary border-b-2 border-transparent rounded-none px-6 py-3 font-semibold"><Battery className="w-4 h-4 mr-2"/> Baterias</TabsTrigger>}
            <TabsTrigger value="attendance" disabled={!formData.equipment_id} className="data-[state=active]:border-primary data-[state=active]:text-primary border-b-2 border-transparent rounded-none px-6 py-3 font-semibold"><FileText className="w-4 h-4 mr-2"/> Descrição</TabsTrigger>
            <TabsTrigger value="photos" disabled={!formData.equipment_id} className="data-[state=active]:border-primary data-[state=active]:text-primary border-b-2 border-transparent rounded-none px-6 py-3 font-semibold"><ImageIcon className="w-4 h-4 mr-2"/> Fotos</TabsTrigger>
            <TabsTrigger value="signatures" disabled={!formData.equipment_id} className="data-[state=active]:border-primary data-[state=active]:text-primary border-b-2 border-transparent rounded-none px-6 py-3 font-semibold"><PenTool className="w-4 h-4 mr-2"/> Assinaturas</TabsTrigger>
          </TabsList>

          <div className="p-6 md:p-8 flex-1">
            <TabsContent value="equipment" className="mt-0 space-y-6 h-full">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl">
                <div className="space-y-2">
                  <Label>Cliente <span className="text-destructive">*</span></Label>
                  <Popover open={clientOpen} onOpenChange={(o) => { if(!isReadOnly) { setClientOpen(o); if (!o) setClientSearchTerm(''); } }}>
                    <PopoverTrigger asChild>
                      <Button variant="outline" role="combobox" aria-expanded={clientOpen} className={cn("w-full justify-between font-normal text-left", !formData.client_id && validationErrors.length > 0 && "border-destructive")}>
                        <span className="truncate">{formData.client_id ? clients.find(c => c.id === formData.client_id)?.name : "Selecione o cliente..."}</span>
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[400px] p-0" align="start">
                      <Command shouldFilter={false}>
                        <CommandInput placeholder="Buscar por nome ou CNPJ..." value={clientSearchTerm} onValueChange={setClientSearchTerm} />
                        <CommandList>
                          {filteredClients.length === 0 ? <div className="p-4 text-center text-sm text-muted-foreground">Nenhum cliente.</div> : (
                            <CommandGroup>
                              {filteredClients.map(c => (
                                <CommandItem key={c.id} value={c.id} onSelect={() => { handleClientChange(c.id); setClientOpen(false); }}>
                                  <Check className={cn("mr-2 h-4 w-4", formData.client_id === c.id ? "opacity-100" : "opacity-0")} />
                                  <div className="flex flex-col">
                                    <span>{c.name}</span>
                                    <span className="text-xs text-muted-foreground">{c.cnpj_cpf}</span>
                                  </div>
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          )}
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-2">
                  <Label>Técnico Responsável <span className="text-destructive">*</span></Label>
                  <Select value={formData.technician_id} onValueChange={handleTechChange} disabled={isReadOnly}>
                    <SelectTrigger className={cn(!formData.technician_id && validationErrors.length > 0 && "border-destructive")}>
                      <SelectValue placeholder="Selecione o técnico..." />
                    </SelectTrigger>
                    <SelectContent>
                      {technicians.map(t => (
                        <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {formData.client_id && (
                <div className="space-y-6">
                  {!selectedEquipmentData ? (
                    <div className="p-6 border rounded-xl bg-muted/30 flex flex-col items-center justify-center space-y-4">
                      <MonitorSmartphone className="h-10 w-10 text-muted-foreground opacity-50" />
                      <div className="text-center">
                        <p className="font-medium text-foreground mb-1">Nenhum equipamento selecionado</p>
                        <p className="text-sm text-muted-foreground mb-4">Selecione um equipamento deste cliente para começar.</p>
                      </div>
                      <Button onClick={() => setEquipmentModalOpen(true)} disabled={isReadOnly} className={cn(!formData.equipment_id && validationErrors.length > 0 && "ring-2 ring-destructive ring-offset-2")}>Selecionar Equipamento</Button>
                    </div>
                  ) : (
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                        <CardTitle className="text-lg font-semibold">Dados do Equipamento Selecionado</CardTitle>
                        {!isReadOnly && <Button variant="outline" size="sm" onClick={() => setEquipmentModalOpen(true)}>Trocar Equipamento</Button>}
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 text-sm">
                          {renderEquipmentField('Tipo', selectedEquipmentData.type)}
                          {renderEquipmentField('Marca', selectedEquipmentData.brand)}
                          {renderEquipmentField('Modelo', selectedEquipmentData.model)}
                          {renderEquipmentField('Número de Série', selectedEquipmentData.serial_number)}
                          {renderEquipmentField('Data de Instalação', formatDate(selectedEquipmentData.installation_date))}
                          {renderEquipmentField('Tipo de Tensão', selectedEquipmentData.voltage_type)}
                          {renderEquipmentField('Potência (VA)', selectedEquipmentData.power_va)}
                          {renderEquipmentField('Tensão Entrada (V)', selectedEquipmentData.voltage_in)}
                          {renderEquipmentField('Tensão Saída (V)', selectedEquipmentData.voltage_out)}
                          {renderEquipmentField('Tensão Bateria (VDC)', selectedEquipmentData.voltage_battery)}
                          {renderEquipmentField('Corrente Bateria', selectedEquipmentData.current_battery)}
                          {renderEquipmentField('Tipo de Bateria', selectedEquipmentData.battery_type)}
                          {renderEquipmentField('Quantidade de Baterias', selectedEquipmentData.battery_quantity)}
                          {renderEquipmentField('Bateria Volts (VDC)', selectedEquipmentData.battery_volts)}
                          {renderEquipmentField('Corrente Bateria (AH/W)', selectedEquipmentData.battery_current)}
                          {renderEquipmentField('Conexão de Baterias', selectedEquipmentData.battery_connection)}
                          {renderEquipmentField('Terminal de Baterias', selectedEquipmentData.battery_terminal)}
                          {renderEquipmentField('Marca da Bateria', selectedEquipmentData.battery_brand)}
                          {renderEquipmentField('Modelo da Bateria', selectedEquipmentData.battery_model)}
                          {renderEquipmentField('Corrente Entrada (A)', selectedEquipmentData.current_in)}
                          {renderEquipmentField('Corrente Saída (A)', selectedEquipmentData.current_out)}
                          {renderEquipmentField('Certificação', selectedEquipmentData.certification)}
                          {renderEquipmentField('Capacidade (AH/W)', selectedEquipmentData.capacity_ah)}
                          {renderEquipmentField('Simétrico', selectedEquipmentData.symmetric)}
                          {renderEquipmentField('Isolado', selectedEquipmentData.isolated)}
                          {renderEquipmentField('Qtd. Sinalizadores', selectedEquipmentData.signalizers_quantity)}
                          {renderEquipmentField('IHM', selectedEquipmentData.ihm)}
                          {renderEquipmentField('Localizadores', selectedEquipmentData.localizadores)}
                          {renderEquipmentField('Tipo de Cabo de Comunicação', selectedEquipmentData.communication_cable_type)}
                          {renderEquipmentField('Fixação', selectedEquipmentData.fixation)}
                          {renderEquipmentField('Quantidade', selectedEquipmentData.quantity)}
                          {renderEquipmentField('Ambiente Refrigerado', selectedEquipmentData.cooled_environment)}
                        </div>

                        {!isReadOnly && (
                          <div className="flex justify-end mt-6 pt-6 border-t">
                            <Button 
                              onClick={handleQuickCreate} 
                              disabled={saving || isReadOnly} 
                              className="bg-secondary text-secondary-foreground hover:bg-secondary/80"
                            >
                              {saving ? <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-2" /> : <Clock className="mr-2 h-4 w-4" />}
                              Criar Relatório Rápido
                            </Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="installation" className="mt-0 space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2 md:col-span-2 lg:col-span-3">
                  <Label>Tipo de Serviço <span className="text-destructive">*</span></Label>
                  <Input 
                    value={formData.service_type} 
                    onChange={e => updateField('service_type', e.target.value.toUpperCase())} 
                    placeholder="Ex: Manutenção Preventiva, Instalação..."
                    className={cn(!formData.service_type && validationErrors.length > 0 && "border-destructive")}
                    disabled={isReadOnly} 
                  />
                </div>
                <div className="space-y-2">
                  <Label>Ambiente Refrigerado</Label>
                  <Select value={formData.cooled_environment} onValueChange={(v) => updateField('cooled_environment', v)} disabled={isReadOnly}>
                    <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                    <SelectContent>{COOLED_ENV_OPTIONS.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Local da Instalação <span className="text-destructive">*</span></Label>
                  <Select value={formData.installation_location} onValueChange={(v) => updateField('installation_location', v)} disabled={isReadOnly}>
                    <SelectTrigger className={cn(!formData.installation_location && validationErrors.length > 0 && "border-destructive")}><SelectValue placeholder="Selecione..." /></SelectTrigger>
                    <SelectContent>{INSTALLATION_LOCATION_OPTIONS.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Tipo de Alimentação <span className="text-destructive">*</span></Label>
                  <Select value={formData.power_supply_type} onValueChange={(v) => updateField('power_supply_type', v)} disabled={isReadOnly}>
                    <SelectTrigger className={cn(!formData.power_supply_type && validationErrors.length > 0 && "border-destructive")}><SelectValue placeholder="Selecione..." /></SelectTrigger>
                    <SelectContent>{POWER_SUPPLY_TYPES.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>

              {formData.installation_location === 'Inadequado' && (
                <div className="space-y-2">
                  <Label>Motivo do Local Inadequado <span className="text-destructive">*</span></Label>
                  <Textarea 
                    value={formData.installation_location_explanation} 
                    onChange={e => updateField('installation_location_explanation', e.target.value.toUpperCase())} 
                    rows={2} 
                    className={cn(!formData.installation_location_explanation && validationErrors.length > 0 && "border-destructive")}
                    disabled={isReadOnly}
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-6 border-t border-border">
                <div className="space-y-2"><Label>Disjuntor</Label><Input value={formData.breaker} onChange={e => updateField('breaker', e.target.value.toUpperCase())} disabled={isReadOnly} /></div>
                <div className="space-y-2"><Label>Cabo Entrada FASE (mm²)</Label><Input type="number" value={formData.cable_entry_phase} onChange={e => updateField('cable_entry_phase', e.target.value)} disabled={isReadOnly} /></div>
                <div className="space-y-2"><Label>Cabo Entrada NEUTRO (mm²)</Label><Input type="number" value={formData.cable_entry_neutral} onChange={e => updateField('cable_entry_neutral', e.target.value)} disabled={isReadOnly} /></div>
                <div className="space-y-2"><Label>Cabo Entrada TERRA (mm²)</Label><Input type="number" value={formData.cable_entry_ground} onChange={e => updateField('cable_entry_ground', e.target.value)} disabled={isReadOnly} /></div>
                <div className="space-y-2"><Label>Cabo Saída FASE (mm²)</Label><Input type="number" value={formData.cable_exit_phase} onChange={e => updateField('cable_exit_phase', e.target.value)} disabled={isReadOnly} /></div>
                <div className="space-y-2"><Label>Cabo Saída NEUTRO (mm²)</Label><Input type="number" value={formData.cable_exit_neutral} onChange={e => updateField('cable_exit_neutral', e.target.value)} disabled={isReadOnly} /></div>
              </div>

              {hasExternalBattery && (
                <div className="space-y-6 pt-6 border-t border-border">
                  <h3 className="text-lg font-semibold text-primary flex items-center">
                    <Battery className="mr-2 h-5 w-5" />
                    Banco Externo
                  </h3>
                  <div className="bg-muted/30 p-6 rounded-xl border space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <Label>Cabo Positivo (mm²)</Label>
                        <Input 
                          type="number" 
                          value={formData.external_battery_positive_cable} 
                          onChange={e => updateField('external_battery_positive_cable', e.target.value)} 
                          disabled={isReadOnly}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Cabo Negativo (mm²)</Label>
                        <Input 
                          type="number" 
                          value={formData.external_battery_negative_cable} 
                          onChange={e => updateField('external_battery_negative_cable', e.target.value)} 
                          disabled={isReadOnly}
                        />
                      </div>
                      {isSymmetric && (
                        <div className="space-y-2">
                          <Label>Cabo Neutro (mm²)</Label>
                          <Input 
                            type="number" 
                            value={formData.external_battery_neutral_cable} 
                            onChange={e => updateField('external_battery_neutral_cable', e.target.value)} 
                            disabled={isReadOnly}
                          />
                        </div>
                      )}
                      <div className="space-y-2">
                        <Label>Conexão Bateria</Label>
                        <Select 
                          value={formData.external_battery_connection} 
                          onValueChange={(v) => updateField('external_battery_connection', v)}
                          disabled={isReadOnly}
                        >
                          <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                          <SelectContent>
                            {EXTERNAL_BATTERY_CONNECTION_OPTIONS.map(opt => (
                              <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Conexão Nobreak</Label>
                        <Select 
                          value={formData.external_battery_nobreak_connection} 
                          onValueChange={(v) => updateField('external_battery_nobreak_connection', v)}
                          disabled={isReadOnly}
                        >
                          <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                          <SelectContent>
                            {EXTERNAL_BATTERY_CONNECTION_OPTIONS.map(opt => (
                              <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="electrical" className="mt-0 space-y-10">
              {!vType && (
                <div className="p-4 bg-destructive/10 text-destructive border border-destructive/20 rounded-lg font-medium text-center">
                  O tipo de tensão não está definido no cadastro deste equipamento. Configure o tipo de tensão no cadastro de equipamentos.
                </div>
              )}

              <div className="space-y-6">
                <h3 className="text-xl font-bold tracking-tight text-primary flex items-center border-b pb-2"><Zap className="mr-2 h-5 w-5" /> Entrada</h3>
                <div className="bg-muted/30 p-6 rounded-xl border space-y-6">
                  {vType === 'MONOFÁSICA' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                      <div className="space-y-2"><Label>Tensão F/N (V)</Label><Input type="number" value={getElecValue('entrada', 'tensions', 'single')} onChange={e => updateElectrical('entrada', 'tensions', 'single', e.target.value)} disabled={isReadOnly} /></div>
                      <div className="space-y-2"><Label>Tensão N/T (V)</Label><Input type="number" value={getElecValue('entrada', 'tensions', 'nt')} onChange={e => updateElectrical('entrada', 'tensions', 'nt', e.target.value)} disabled={isReadOnly} /></div>
                      <div className="space-y-2"><Label>Corrente Fase (A)</Label><Input type="number" value={getElecValue('entrada', 'currents', 'single')} onChange={e => updateElectrical('entrada', 'currents', 'single', e.target.value)} disabled={isReadOnly} /></div>
                      <div className="space-y-2"><Label>Corrente Neutro (A)</Label><Input type="number" value={getElecValue('entrada', 'currents', 'neutral')} onChange={e => updateElectrical('entrada', 'currents', 'neutral', e.target.value)} disabled={isReadOnly} /></div>
                      <div className="space-y-2"><Label>Corrente Terra (A)</Label><Input type="number" value={getElecValue('entrada', 'currents', 'ground')} onChange={e => updateElectrical('entrada', 'currents', 'ground', e.target.value)} disabled={isReadOnly} /></div>
                    </div>
                  )}
                  {(vType === 'TRIFÁSICA' || vType === 'TRIMONO') && (
                    <>
                      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-4">
                        <div className="space-y-2"><Label>Tensão R/S</Label><Input type="number" value={getElecValue('entrada', 'tensions', 'rs')} onChange={e => updateElectrical('entrada', 'tensions', 'rs', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão S/T</Label><Input type="number" value={getElecValue('entrada', 'tensions', 'st')} onChange={e => updateElectrical('entrada', 'tensions', 'st', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão R/T</Label><Input type="number" value={getElecValue('entrada', 'tensions', 'rt')} onChange={e => updateElectrical('entrada', 'tensions', 'rt', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão R/N</Label><Input type="number" value={getElecValue('entrada', 'tensions', 'rn')} onChange={e => updateElectrical('entrada', 'tensions', 'rn', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão S/N</Label><Input type="number" value={getElecValue('entrada', 'tensions', 'sn')} onChange={e => updateElectrical('entrada', 'tensions', 'sn', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão T/N</Label><Input type="number" value={getElecValue('entrada', 'tensions', 'tn')} onChange={e => updateElectrical('entrada', 'tensions', 'tn', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão Neutro/Terra</Label><Input type="number" value={getElecValue('entrada', 'tensions', 'nt')} onChange={e => updateElectrical('entrada', 'tensions', 'nt', e.target.value)} disabled={isReadOnly} /></div>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4 pt-4 border-t border-border/50">
                        <div className="space-y-2"><Label>Corrente R (A)</Label><Input type="number" value={getElecValue('entrada', 'currents', 'r')} onChange={e => updateElectrical('entrada', 'currents', 'r', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Corrente S (A)</Label><Input type="number" value={getElecValue('entrada', 'currents', 's')} onChange={e => updateElectrical('entrada', 'currents', 's', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Corrente T (A)</Label><Input type="number" value={getElecValue('entrada', 'currents', 't')} onChange={e => updateElectrical('entrada', 'currents', 't', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Corrente Neutro (A)</Label><Input type="number" value={getElecValue('entrada', 'currents', 'neutral')} onChange={e => updateElectrical('entrada', 'currents', 'neutral', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Corrente Terra (A)</Label><Input type="number" value={getElecValue('entrada', 'currents', 'ground')} onChange={e => updateElectrical('entrada', 'currents', 'ground', e.target.value)} disabled={isReadOnly} /></div>
                      </div>
                    </>
                  )}
                </div>
              </div>

              <div className="space-y-6">
                <h3 className="text-xl font-bold tracking-tight text-primary flex items-center border-b pb-2"><Zap className="mr-2 h-5 w-5" /> Saída</h3>
                <div className="bg-muted/30 p-6 rounded-xl border space-y-6">
                  {(vType === 'MONOFÁSICA' || vType === 'TRIMONO') && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                      <div className="space-y-2"><Label>Tensão F/N (V)</Label><Input type="number" value={getElecValue('saida', 'tensions', 'single')} onChange={e => updateElectrical('saida', 'tensions', 'single', e.target.value)} disabled={isReadOnly} /></div>
                      <div className="space-y-2"><Label>Tensão N/T (V)</Label><Input type="number" value={getElecValue('saida', 'tensions', 'nt')} onChange={e => updateElectrical('saida', 'tensions', 'nt', e.target.value)} disabled={isReadOnly} /></div>
                      <div className="space-y-2"><Label>Corrente Fase (A)</Label><Input type="number" value={getElecValue('saida', 'currents', 'single')} onChange={e => updateElectrical('saida', 'currents', 'single', e.target.value)} disabled={isReadOnly} /></div>
                      <div className="space-y-2"><Label>Corrente Neutro (A)</Label><Input type="number" value={getElecValue('saida', 'currents', 'neutral')} onChange={e => updateElectrical('saida', 'currents', 'neutral', e.target.value)} disabled={isReadOnly} /></div>
                    </div>
                  )}
                  {vType === 'TRIFÁSICA' && (
                    <>
                      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-4">
                        <div className="space-y-2"><Label>Tensão R/S</Label><Input type="number" value={getElecValue('saida', 'tensions', 'rs')} onChange={e => updateElectrical('saida', 'tensions', 'rs', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão S/T</Label><Input type="number" value={getElecValue('saida', 'tensions', 'st')} onChange={e => updateElectrical('saida', 'tensions', 'st', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão R/T</Label><Input type="number" value={getElecValue('saida', 'tensions', 'rt')} onChange={e => updateElectrical('saida', 'tensions', 'rt', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão R/N</Label><Input type="number" value={getElecValue('saida', 'tensions', 'rn')} onChange={e => updateElectrical('saida', 'tensions', 'rn', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão S/N</Label><Input type="number" value={getElecValue('saida', 'tensions', 'sn')} onChange={e => updateElectrical('saida', 'tensions', 'sn', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão T/N</Label><Input type="number" value={getElecValue('saida', 'tensions', 'tn')} onChange={e => updateElectrical('saida', 'tensions', 'tn', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Tensão N/T</Label><Input type="number" value={getElecValue('saida', 'tensions', 'nt')} onChange={e => updateElectrical('saida', 'tensions', 'nt', e.target.value)} disabled={isReadOnly} /></div>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4 pt-4 border-t border-border/50">
                        <div className="space-y-2"><Label>Corrente R (A)</Label><Input type="number" value={getElecValue('saida', 'currents', 'r')} onChange={e => updateElectrical('saida', 'currents', 'r', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Corrente S (A)</Label><Input type="number" value={getElecValue('saida', 'currents', 's')} onChange={e => updateElectrical('saida', 'currents', 's', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Corrente T (A)</Label><Input type="number" value={getElecValue('saida', 'currents', 't')} onChange={e => updateElectrical('saida', 'currents', 't', e.target.value)} disabled={isReadOnly} /></div>
                        <div className="space-y-2"><Label>Corrente Neutro (A)</Label><Input type="number" value={getElecValue('saida', 'currents', 'neutral')} onChange={e => updateElectrical('saida', 'currents', 'neutral', e.target.value)} disabled={isReadOnly} /></div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </TabsContent>

            {hasBattery && (
              <TabsContent value="battery" className="mt-0 space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label>Banco de Baterias</Label>
                    <Select value={formData.battery_bank.type} onValueChange={v => updateBattery('type', v)} disabled={isReadOnly}>
                      <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                      <SelectContent>{BATTERY_TYPES.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Quantidade Baterias</Label>
                    <Input type="number" value={formData.battery_bank.quantity} onChange={e => updateBattery('quantity', e.target.value)} disabled={isReadOnly} />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Bateria Volts (VDC)</Label>
                    <Input type="number" value={formData.battery_bank.battery_volts} onChange={e => updateBattery('battery_volts', e.target.value)} disabled={isReadOnly} />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Corrente Bateria (Ah/W)</Label>
                    <Input value={formData.battery_bank.battery_current} onChange={e => updateBattery('battery_current', e.target.value.toUpperCase())} disabled={isReadOnly} />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Tensão do Banco +/- (VDC)</Label>
                    <Input type="number" value={formData.battery_bank.voltage} onChange={e => updateBattery('voltage', e.target.value)} disabled={isReadOnly} />
                  </div>
                  
                  {isSymmetric && (
                    <>
                      <div className="space-y-2">
                        <Label>Tensão do Banco +/N (VDC)</Label>
                        <Input type="number" value={formData.battery_bank.voltage_positive_neutral} onChange={e => updateBattery('voltage_positive_neutral', e.target.value)} disabled={isReadOnly} />
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Tensão do Banco N/- (VDC)</Label>
                        <Input type="number" value={formData.battery_bank.voltage_neutral_negative} onChange={e => updateBattery('voltage_neutral_negative', e.target.value)} disabled={isReadOnly} />
                      </div>
                    </>
                  )}
                  
                  <div className="space-y-2">
                    <Label>Tensão Carregador (VDC)</Label>
                    <Input type="number" value={formData.battery_bank.charger_voltage} onChange={e => updateBattery('charger_voltage', e.target.value)} disabled={isReadOnly} />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Marca</Label>
                    <Input value={formData.battery_bank.brand} onChange={e => updateBattery('brand', e.target.value.toUpperCase())} disabled={isReadOnly} />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Modelo</Label>
                    <Input value={formData.battery_bank.model} onChange={e => updateBattery('model', e.target.value.toUpperCase())} disabled={isReadOnly} />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Trocou Baterias</Label>
                    <Select value={formData.battery_bank.trocou_baterias} onValueChange={v => updateBattery('trocou_baterias', v)} disabled={isReadOnly}>
                      <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                      <SelectContent>{YES_NO_OPTIONS.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  
                  {trocouBaterias === 'SIM' && (
                    <div className="space-y-2">
                      <Label>Última Troca</Label>
                      <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
                        <PopoverTrigger asChild>
                          <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !formData.battery_bank.last_change && "text-muted-foreground")} disabled={isReadOnly}>
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {formData.battery_bank.last_change ? formatDateForDisplay(formData.battery_bank.last_change) : "Selecione a data"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={formData.battery_bank.last_change ? new Date(formData.battery_bank.last_change) : undefined}
                            onSelect={(date) => {
                              updateBattery('last_change', date ? date.toISOString().split('T')[0] : '');
                              setDatePickerOpen(false);
                            }}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  )}
                  
                  {trocouBaterias === 'NÃO' && (
                    <div className="space-y-2 sm:col-span-2 lg:col-span-3">
                      <Label>Motivo</Label>
                      <Textarea 
                        value={formData.battery_bank.motivo_nao_troca} 
                        onChange={e => updateBattery('motivo_nao_troca', e.target.value.toUpperCase())} 
                        rows={2}
                        disabled={isReadOnly}
                      />
                    </div>
                  )}
                </div>
              </TabsContent>
            )}

            <TabsContent value="attendance" className="mt-0 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2"><Label>Inspeção Externa</Label><Textarea rows={4} value={formData.external_inspection} onChange={e => updateField('external_inspection', e.target.value.toUpperCase())} disabled={isReadOnly} /></div>
                <div className="space-y-2"><Label>Inspeção Interna</Label><Textarea rows={4} value={formData.internal_inspection} onChange={e => updateField('internal_inspection', e.target.value.toUpperCase())} disabled={isReadOnly} /></div>
              </div>
              <div className="space-y-2"><Label>Realizado no Atendimento</Label><Textarea rows={4} value={formData.attendance_description} onChange={e => updateField('attendance_description', e.target.value.toUpperCase())} disabled={isReadOnly} /></div>
              <div className="space-y-2"><Label>Diagnóstico / Necessário</Label><Textarea rows={4} value={formData.diagnosis} onChange={e => updateField('diagnosis', e.target.value.toUpperCase())} disabled={isReadOnly} /></div>
              <div className="space-y-2"><Label>Conclusão / Resultado</Label><Textarea rows={4} value={formData.conclusion} onChange={e => updateField('conclusion', e.target.value.toUpperCase())} disabled={isReadOnly} /></div>
            </TabsContent>

            <TabsContent value="photos" className="mt-0 space-y-6">
              {!isReadOnly && (
                <div className="border-2 border-dashed rounded-xl p-8 text-center bg-muted/20 hover:bg-muted/40 transition-colors">
                  <Upload className="mx-auto h-12 w-12 text-muted-foreground/50 mb-4" />
                  <Label htmlFor="photo-upload" className="cursor-pointer">
                    <span className="text-primary font-semibold hover:underline">Clique para adicionar fotos</span>
                    <span className="text-muted-foreground block text-sm mt-1">Formato JPG, PNG (Max 5MB)</span>
                  </Label>
                  <Input id="photo-upload" type="file" accept="image/*" multiple onChange={handlePhotoUpload} className="hidden" disabled={isReadOnly} />
                </div>
              )}
              
              {photos.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
                  {photos.map((photo) => (
                    <div key={photo.id} className="group relative border rounded-xl overflow-hidden bg-card shadow-sm flex flex-col">
                      <div className="aspect-video relative bg-muted shrink-0">
                        <img src={photo.url} alt="Foto" className="w-full h-full object-cover cursor-pointer" onClick={() => setZoomPhoto(photo.url)} />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                          <Button variant="secondary" size="icon" className="h-8 w-8 rounded-full" onClick={() => setZoomPhoto(photo.url)}><ZoomIn className="h-4 w-4" /></Button>
                          {!isReadOnly && (
                            <Button variant="destructive" size="icon" className="h-8 w-8 rounded-full" onClick={() => removePhoto(photo.id)}><X className="h-4 w-4" /></Button>
                          )}
                        </div>
                      </div>
                      <div className="p-3 space-y-2 flex-1 flex flex-col">
                        <Textarea 
                          placeholder="Comentário da foto..." 
                          className="text-xs resize-none flex-1 min-h-[60px]" 
                          value={photo.comment} 
                          onChange={e => updatePhoto(photo.id, 'comment', e.target.value.toUpperCase())} 
                          disabled={isReadOnly}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="signatures" className="mt-0 space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                <div className="space-y-4 border p-6 rounded-xl bg-card shadow-sm">
                  <h4 className="font-semibold text-lg flex items-center border-b pb-2"><PenTool className="mr-2 w-5 h-5"/> Assinatura Técnica</h4>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Nome do Técnico</Label>
                      <Input value={selectedTech?.name || ''} readOnly className="bg-muted text-muted-foreground" />
                    </div>
                    <div className="space-y-2">
                      <Label>Assinatura <span className="text-destructive">*</span></Label>
                      {formData.technician_signature ? (
                        <div className="space-y-2">
                          <div className="border bg-white rounded-xl p-4 flex justify-center">
                            <img src={formData.technician_signature} alt="Assinatura do Técnico" className="max-w-full max-h-32 object-contain" />
                          </div>
                          {!isReadOnly && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={redrawTechSignature}
                              className="w-full"
                            >
                              Redesenhar Assinatura
                            </Button>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="border rounded-lg overflow-hidden bg-white ring-1 ring-border shadow-inner">
                            <SignatureCanvas 
                              ref={techSigPad}
                              penColor="#3B82F6"
                              backgroundColor="white"
                              canvasProps={{ 
                                className: 'w-full touch-none', 
                                style: { minHeight: '200px', maxWidth: '400px', margin: '0 auto', display: 'block' } 
                              }}
                            />
                          </div>
                          {!isReadOnly && (
                            <div className="flex gap-2">
                              <Button 
                                type="button"
                                variant="outline" 
                                size="sm" 
                                onClick={clearTechSignature}
                                className="flex-1"
                              >
                                Limpar
                              </Button>
                              <Button 
                                type="button"
                                size="sm" 
                                onClick={handleConfirmTechSignature}
                                className="flex-1"
                              >
                                Confirmar Assinatura
                              </Button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className={cn("space-y-4 border p-6 rounded-xl bg-card shadow-sm", (!formData.client_signature && validationErrors.length > 0) && "border-destructive ring-1 ring-destructive")}>
                  <h4 className="font-semibold text-lg flex items-center border-b pb-2"><PenTool className="mr-2 w-5 h-5"/> Assinatura do Cliente</h4>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Nome do Cliente / Responsável <span className="text-destructive">*</span></Label>
                      <Input value={formData.responsible_person} onChange={e => updateField('responsible_person', e.target.value.toUpperCase())} className={cn(!formData.responsible_person && validationErrors.length > 0 && "border-destructive")} disabled={isReadOnly} />
                    </div>
                    <div className="space-y-2">
                      <Label>Assinatura <span className="text-destructive">*</span></Label>
                      {formData.client_signature ? (
                        <div className="space-y-2">
                          <div className="border bg-white rounded-xl p-4 flex justify-center">
                            <img src={formData.client_signature} alt="Assinatura do Cliente" className="max-w-full max-h-32 object-contain" />
                          </div>
                          {!isReadOnly && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={redrawClientSignature}
                              className="w-full"
                            >
                              Redesenhar Assinatura
                            </Button>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="border rounded-lg overflow-hidden bg-white ring-1 ring-border shadow-inner">
                            <SignatureCanvas 
                              ref={clientSigPad}
                              penColor="#3B82F6"
                              backgroundColor="white"
                              canvasProps={{ 
                                className: 'w-full touch-none', 
                                style: { minHeight: '200px', maxWidth: '400px', margin: '0 auto', display: 'block' } 
                              }}
                            />
                          </div>
                          {!isReadOnly && (
                            <div className="flex gap-2">
                              <Button 
                                type="button"
                                variant="outline" 
                                size="sm" 
                                onClick={clearClientSignature}
                                className="flex-1"
                              >
                                Limpar
                              </Button>
                              <Button 
                                type="button"
                                size="sm" 
                                onClick={handleConfirmSignature}
                                className="flex-1"
                              >
                                Confirmar Assinatura
                              </Button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </div>
          
          <div className="bg-muted/50 border-t p-4 md:px-8 md:py-5 flex flex-col sm:flex-row justify-between items-center gap-4 mt-auto">
            <div className="w-full sm:w-auto flex gap-3">
              <Button variant="outline" onClick={handleCancel} className="w-full sm:w-auto">Cancelar / Voltar</Button>
              {tabsOrder.indexOf(activeTab) > 0 && (
                <Button variant="secondary" onClick={handlePrevTab} className="w-full sm:w-auto">
                  <ArrowLeft className="mr-2 h-4 w-4" /> Voltar Etapa
                </Button>
              )}
            </div>

            <div className="flex flex-col sm:flex-row w-full sm:w-auto gap-3">
              {activeTab !== 'signatures' ? (
                <Button onClick={handleNextTab} className="w-full sm:w-auto min-w-[140px]" disabled={!formData.equipment_id}>
                  Próxima <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Button 
                  onClick={handleCreateDraft} 
                  disabled={saving || !formData.equipment_id}
                  className="w-full sm:w-auto min-w-[160px]"
                >
                  {saving ? <div className="animate-spin h-4 w-4 border-2 border-primary-foreground border-t-transparent rounded-full mr-2" /> : <Save className="mr-2 h-4 w-4" />}
                  Criar Relatório
                </Button>
              )}
            </div>
          </div>
        </Tabs>
      </fieldset>

      <Dialog open={!!zoomPhoto} onOpenChange={() => setZoomPhoto(null)}>
        <DialogContent className="max-w-4xl p-1 bg-transparent border-none shadow-none">
          {zoomPhoto && <img src={zoomPhoto} alt="Zoomed" className="w-full h-auto max-h-[85vh] object-contain rounded-lg shadow-2xl" />}
        </DialogContent>
      </Dialog>

      <EquipmentSelectionModal 
        isOpen={equipmentModalOpen}
        onClose={() => setEquipmentModalOpen(false)}
        equipments={clientEquipments}
        includedIds={[formData.equipment_id]}
        onSelect={selectEquipment}
      />
    </div>
  );
}
