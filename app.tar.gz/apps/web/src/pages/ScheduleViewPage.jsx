import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import pb from '@/lib/pocketbaseClient.js';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { format, differenceInHours, differenceInMinutes } from 'date-fns';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Skeleton } from '@/components/ui/skeleton';

export default function ScheduleViewPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [schedule, setSchedule] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSchedule();
  }, [id]);

  const fetchSchedule = async () => {
    try {
      const record = await pb.collection('schedules').getOne(id, {
        expand: 'client_id,equipment_id,tecnico_responsavel',
        $autoCancel: false
      });
      setSchedule(record);
      setLoading(false);
    } catch (error) {
      toast.error('ERRO AO CARREGAR AGENDAMENTO');
      setLoading(false);
      navigate('/schedules');
    }
  };

  const getStatusColor = (schedule) => {
    if (!schedule) return 'bg-gray-500';

    const now = new Date();
    const scheduledTime = new Date(schedule.data_hora_agendamento);
    const minutesDiff = differenceInMinutes(scheduledTime, now);
    const hoursDiff = differenceInHours(scheduledTime, now);

    // Priority 1: REALIZANDO (Em Andamento) always BLUE
    if (schedule.status === 'Em Andamento') {
      return 'bg-blue-500';
    }

    // Priority 2: Atrasado (>1min late AND status≠Em Andamento) → RED
    if (minutesDiff < -1 && schedule.status !== 'Em Andamento') {
      return 'bg-red-500';
    }

    // Priority 3: <12h before → YELLOW
    if (hoursDiff < 12 && hoursDiff >= 0) {
      return 'bg-yellow-500';
    }

    // Priority 4: ≥15h before → GREEN
    if (hoursDiff >= 15) {
      return 'bg-green-500';
    }

    // Default status colors
    switch (schedule.status) {
      case 'Aberto': return 'bg-green-500';
      case 'Finalizado': return 'bg-red-500';
      case 'Realizado': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const handleStatusChange = async (newStatus) => {
    try {
      await pb.collection('schedules').update(id, { status: newStatus }, { $autoCancel: false });
      setSchedule(prev => ({ ...prev, status: newStatus }));
      toast.success('STATUS ATUALIZADO COM SUCESSO');
    } catch (error) {
      toast.error('ERRO AO ATUALIZAR STATUS');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Skeleton className="h-8 w-48 mb-6" />
          <div className="space-y-4">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-64 w-full" />)}
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!schedule) {
    return null;
  }

  const client = schedule.expand?.client_id;
  const equipment = schedule.expand?.equipment_id;
  const technician = schedule.expand?.tecnico_responsavel;

  // Address fields with fallback logic
  const ruaStr = client?.rua || client?.address || '';
  const numStr = client?.numero || client?.number || '';
  const bairroStr = client?.bairro || client?.neighborhood || '';
  const cidadeStr = client?.cidade || client?.city || '';
  const ufStr = client?.uf || client?.state || '';

  // Build a formatted address string for the map search query
  const addressParts = [];
  if (ruaStr || numStr) {
    addressParts.push([ruaStr, numStr].filter(Boolean).join(', '));
  }
  if (bairroStr) {
    addressParts.push(bairroStr);
  }
  if (cidadeStr || ufStr) {
    addressParts.push([cidadeStr, ufStr].filter(Boolean).join(' - '));
  }
  
  const fullAddress = addressParts.join(' - ');
  const encodedAddress = encodeURIComponent(fullAddress || (client?.name || ''));
  
  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodedAddress}`;
  const wazeUrl = `https://waze.com/ul?q=${encodedAddress}`;

  const canChangeStatus = currentUser?.id === schedule.tecnico_responsavel;

  return (
    <>
      <Helmet>
        <title>{`AGENDAMENTO #${id} - FATTAX`}</title>
        <meta name="description" content="Visualização de agendamento técnico" />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1 container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-6">
            <Button variant="ghost" onClick={() => navigate('/schedules')} className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              VOLTAR PARA AGENDAMENTOS
            </Button>
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-3xl font-bold mb-2" style={{ letterSpacing: '-0.02em' }}>
                  AGENDAMENTO #{id.slice(-6).toUpperCase()}
                </h1>
                <p className="text-muted-foreground">
                  {format(new Date(schedule.data_hora_agendamento), 'dd/MM/yyyy HH:mm')}
                </p>
              </div>
              <Badge className={`${getStatusColor(schedule)} text-white text-lg px-4 py-2`}>
                {schedule.status.toUpperCase()}
              </Badge>
            </div>
          </div>

          <div className="space-y-6">
            {/* Client Info */}
            <div className="bg-card rounded-lg border p-6">
              <h2 className="text-xl font-semibold mb-4">INFORMAÇÕES DO CLIENTE</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:col-span-2">
                  <div>
                    <p className="text-sm text-muted-foreground">NOME</p>
                    <p className="font-medium">{client?.name || '-'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">CNPJ/CPF</p>
                    <p className="font-medium">{client?.cnpj_cpf || '-'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">TELEFONE</p>
                    <p className="font-medium">{client?.phone || client?.mobile || '-'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">E-MAIL</p>
                    <p className="font-medium">{client?.email || '-'}</p>
                  </div>
                </div>

                <div className="md:col-span-2 mt-2">
                  <h3 className="text-sm font-semibold text-muted-foreground border-b pb-2 mb-4 uppercase tracking-wide">
                    ENDEREÇO
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="sm:col-span-2 md:col-span-2">
                      <p className="text-sm text-muted-foreground">RUA</p>
                      <p className="font-medium">{ruaStr || '-'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">NÚMERO</p>
                      <p className="font-medium">{numStr || '-'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">BAIRRO</p>
                      <p className="font-medium">{bairroStr || '-'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">CIDADE</p>
                      <p className="font-medium">{cidadeStr || '-'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">UF</p>
                      <p className="font-medium">{ufStr || '-'}</p>
                    </div>
                  </div>
                </div>
              </div>

              {client && (
                <div className="mt-6 border-t pt-4">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button disabled={!fullAddress}>
                        <MapPin className="mr-2 h-4 w-4" />
                        ABRIR NO MAPA
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem onClick={() => window.open(googleMapsUrl, '_blank')}>
                        GOOGLE MAPS
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => window.open(wazeUrl, '_blank')}>
                        WAZE
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              )}
            </div>

            {/* Equipment Info */}
            <div className="bg-card rounded-lg border p-6">
              <h2 className="text-xl font-semibold mb-4">INFORMAÇÕES DO EQUIPAMENTO</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">TIPO</p>
                  <p className="font-medium">{equipment?.type || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">MARCA</p>
                  <p className="font-medium">{equipment?.brand || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">MODELO</p>
                  <p className="font-medium">{equipment?.model || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">NÚMERO DE SÉRIE</p>
                  <p className="font-medium">{equipment?.numero_serie || equipment?.serial_number || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">POTÊNCIA</p>
                  <p className="font-medium">{equipment?.power_va ? `${equipment.power_va} VA` : '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">TENSÃO ENTRADA</p>
                  <p className="font-medium">{equipment?.voltage_in ? `${equipment.voltage_in} V` : '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">TENSÃO SAÍDA</p>
                  <p className="font-medium">{equipment?.voltage_out ? `${equipment.voltage_out} V` : '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">CORRENTE ENTRADA</p>
                  <p className="font-medium">{equipment?.current_in ? `${equipment.current_in} A` : '-'}</p>
                </div>
              </div>
            </div>

            {/* Schedule Info */}
            <div className="bg-card rounded-lg border p-6">
              <h2 className="text-xl font-semibold mb-4">INFORMAÇÕES DO AGENDAMENTO</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">DATA/HORA</p>
                  <p className="font-medium">
                    {format(new Date(schedule.data_hora_agendamento), 'dd/MM/yyyy HH:mm')}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">TÉCNICO RESPONSÁVEL</p>
                  <p className="font-medium">{technician?.name || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">STATUS</p>
                  {canChangeStatus ? (
                    <Select value={schedule.status} onValueChange={handleStatusChange}>
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Aberto">ABERTO</SelectItem>
                        <SelectItem value="Em Andamento">EM ANDAMENTO</SelectItem>
                        <SelectItem value="Realizado">REALIZADO</SelectItem>
                        <SelectItem value="Finalizado">FINALIZADO</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <p className="font-medium">{schedule.status.toUpperCase()}</p>
                  )}
                </div>
                {schedule.description && (
                  <div className="md:col-span-2">
                    <p className="text-sm text-muted-foreground">OBSERVAÇÕES</p>
                    <p className="font-medium whitespace-pre-wrap">{schedule.description}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}