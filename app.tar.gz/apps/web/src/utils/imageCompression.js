export const compressImage = (file, maxSizeKB = 500) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target.result;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        
        // Max dimensions to help reduce size
        const maxDim = 1200;
        if (width > height && width > maxDim) {
          height *= maxDim / width;
          width = maxDim;
        } else if (height > maxDim) {
          width *= maxDim / height;
          height = maxDim;
        }
        
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        let quality = 0.9;
        let dataUrl = canvas.toDataURL('image/jpeg', quality);

        // Calculate approximate size in KB
        const getKbSize = (dataUrlStr) => {
          const strLength = dataUrlStr.length - 'data:image/jpeg;base64,'.length;
          const sizeInBytes = 4 * Math.ceil((strLength / 3)) * 0.5624896334383812;
          return sizeInBytes / 1024;
        };

        while (getKbSize(dataUrl) > maxSizeKB && quality > 0.1) {
          quality -= 0.1;
          dataUrl = canvas.toDataURL('image/jpeg', quality);
        }

        // Convert back to Blob/File
        const byteString = atob(dataUrl.split(',')[1]);
        const mimeString = dataUrl.split(',')[0].split(':')[1].split(';')[0];
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
          ia[i] = byteString.charCodeAt(i);
        }
        const blob = new Blob([ab], { type: mimeString });
        const compressedFile = new File([blob], file.name, { type: mimeString });

        resolve({ file: compressedFile, dataUrl });
      };
      img.onerror = reject;
    };
    reader.onerror = reject;
  });
};